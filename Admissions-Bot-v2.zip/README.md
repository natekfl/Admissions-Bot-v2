# Admissions-Bot-v2
The official bot for the IRF Admissions. Feel free to make changes and submit them, if you feel so inclined.
